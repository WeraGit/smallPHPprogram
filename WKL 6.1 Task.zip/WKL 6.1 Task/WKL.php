<?php
// WKL 17/09/2020
// Moving from Theory to practice - Task 6.1 

	ini_set('display_errors', 'On');
	error_reporting(E_ALL);

	include('openCage/AbstractGeocoder.php');
	include('openCage/Geocoder.php');

	$geocoder = new \OpenCage\Geocoder\Geocoder('feadcbefaad04cfcbc405b05294a02e1');
	// '40.6892,-74.0445' can be instead of $_REQUEST['q'] below
	$result = $geocoder->geocode($_REQUEST['q']);
	$searchResult = [];
	$searchResult['results'] = [];

	$temp = [];

	foreach ($result['results'] as $entry) {

		$temp['source'] = 'opencage';
		$temp['formatted'] = $entry['formatted'];
		$temp['geometry']['lat'] = $entry['geometry']['lat'];
		$temp['geometry']['lng'] = $entry['geometry']['lng'];
		$temp['country'] = $entry['components']['country'];
		$temp['what3words']['3w'] = $entry['annotations']['what3words'];
		$temp['timezone'] = $entry['annotations']['timezone']['name'];
		$temp['message from W'] = 'Oh, Hello there!';

		array_push($searchResult['results'], $temp);

	}

	header('Content-Type: application/json; charset=UTF-8');
	
	echo json_encode($searchResult, JSON_UNESCAPED_UNICODE);


?>

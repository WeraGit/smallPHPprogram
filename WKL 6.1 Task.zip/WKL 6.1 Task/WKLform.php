<!-- WKL 17/09/2020
Moving from Theory to practice - Task 6.1  -->

<br><br><br>
<form method="get" action="WKL.php">

Enter your coordinates here: <br>
<input type="text" name="q"><br><br>

If you don't have any coordinates handy, here are examples few examples which you can copy and paste:
<ul>
<li>Statue of Liberty:  40.6892,-74.0445 </li>
<li>Eiffel Tower:  48.8584,2.2945 </li>
<li>London:  51.5074,0.1278 </li>
</ul>
Please make sure you enter the coordinates in this format XX.XXXX,XX.XXXX
<br>
<input type="submit" value="Submit">

</form>

